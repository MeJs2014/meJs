me.config.extend("common", {
    alias: {
        "jQuery": "lib/jquery-1.7.2.min.js"
    }
});