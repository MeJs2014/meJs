namespace("demo").extend("plugin", {
    destruct: function(){

    }
});