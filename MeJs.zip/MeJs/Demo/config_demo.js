me.config.extend("demo", {
    alias: {
        plugin: "plugin/plugin.js",
        msgBox: "plugin/msgBox.js",
        print: "plugin/print.js"
    }
});